function Show-WpfWindow {
    Add-Type -AssemblyName PresentationFramework

    [xml]$xaml = Get-Content "$PSScriptRoot\..\UI\MainWindow.xaml" -Raw
    $reader = (New-Object System.Xml.XmlNodeReader $xaml)
    $window = [Windows.Markup.XamlReader]::Load($reader)

    $MenuList = $window.FindName("MenuList")
    $BtnRun = $window.FindName("BtnRun")
    $GridOut = $window.FindName("GridOut")
    $LblStatus = $window.FindName("LblStatus")

    $global:SelectedAction = $null

    $MenuList.ItemsSource = Get-ActionList
    $MenuList.SelectionChanged.Add({
        $global:SelectedAction = $MenuList.SelectedItem
        $LblStatus.Text = "Selected: $SelectedAction"
    })

    $BtnRun.Add_Click({
        if ($global:SelectedAction) {
            $LblStatus.Text = "Running: $global:SelectedAction"
            $data = Run-SelectedAction $global:SelectedAction
            if ($data) {
                $GridOut.ItemsSource = $data
                $LblStatus.Text = "Completed: $global:SelectedAction"
            } else {
                $LblStatus.Text = "No results returned."
            }
        }
    })

    $window.ShowDialog() | Out-Null
}
