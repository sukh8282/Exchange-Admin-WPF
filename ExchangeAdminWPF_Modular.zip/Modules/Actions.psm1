function Get-ActionList {
    return @(
        'List Inactive Mailboxes',
        'Mailbox Permissions Report',
        'Shared Mailbox Statistics',
        'Connect to EXO',
        'Disconnect EXO'
    )
}

function Run-SelectedAction($actionName) {
    switch ($actionName) {
        'List Inactive Mailboxes' {
            return Get-Mailbox -InactiveMailboxOnly -ResultSize Unlimited | Select-Object DisplayName,PrimarySmtpAddress,WhenSoftDeleted
        }
        'Mailbox Permissions Report' {
            return Get-Mailbox -ResultSize Unlimited | ForEach-Object {
                $mbx = $_
                Get-MailboxPermission -Identity $mbx.Identity | Where-Object {
                    $_.User -notlike "NT AUTHORITY*" -and $_.User -ne "S-1-5-32-544"
                } | Select-Object @{Name='Mailbox';Expression={$mbx.DisplayName}},User,AccessRights,IsInherited
            }
        }
        'Shared Mailbox Statistics' {
            return Get-Mailbox -ResultSize Unlimited -RecipientTypeDetails SharedMailbox | ForEach-Object {
                $stats = Get-MailboxStatistics -Identity $_.UserPrincipalName
                [PSCustomObject]@{
                    Mailbox           = $_.DisplayName
                    LastLogonTime     = $stats.LastLogonTime
                    TotalItemSize     = $stats.TotalItemSize
                    ItemCount         = $stats.ItemCount
                }
            }
        }
        'Connect to EXO' {
            Connect-ExchangeOnline -ShowBanner:$false
            return @([pscustomobject]@{Status='Connected to Exchange Online'})
        }
        'Disconnect EXO' {
            Disconnect-ExchangeOnline -Confirm:$false
            return @([pscustomobject]@{Status='Disconnected'})
        }
        default {
            return @([pscustomobject]@{Message="Action '$actionName' not implemented"})
        }
    }
}
