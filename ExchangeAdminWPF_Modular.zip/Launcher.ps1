# Exchange Admin WPF - Modular Launcher
Import-Module "$PSScriptRoot\Modules\Helpers.psm1" -Force
Import-Module "$PSScriptRoot\Modules\Actions.psm1" -Force

Show-WpfWindow
